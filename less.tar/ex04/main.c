#include <stdio.h>
#include <limits.h>

void	ft_putnbr_base(int nbr, char *base);

int main(void) {
  ft_putnbr_base(10, "abcde"); 
 
  putchar('\n');

  //Binário
  puts("Binario:");
  ft_putnbr_base(10, "01");
  putchar('\n');
  ft_putnbr_base(1003, "01");
  putchar('\n');
  
  ft_putnbr_base(INT_MAX, "01");
  putchar('\n');
  ft_putnbr_base(INT_MIN, "01");
  putchar('\n');

 //Octal
  puts("Octal:");
  ft_putnbr_base(10, "01234567");
  putchar('\n');
  ft_putnbr_base(1003, "01234567");
  putchar('\n');
  ft_putnbr_base(INT_MAX, "01234567");
  putchar('\n');
  ft_putnbr_base(INT_MIN, "01234567");
  putchar('\n');
  ft_putnbr_base(1234, "mrdoc"); //BUG AQUI

 putchar('\n');

  //Hexa-Decimal
  puts("Hexa:");
  ft_putnbr_base(10, "0123456789ABCDEF");
  putchar('\n');
  ft_putnbr_base(1003, "0123456789ABCDEF");
  putchar('\n');
  ft_putnbr_base(10, "0123456789ABCDEF");
  putchar('\n');
  ft_putnbr_base(1003, "0123456789ABCDEF");
  putchar('\n');
  ft_putnbr_base(INT_MAX, "0123456789ABCDEF");
  putchar('\n');
  ft_putnbr_base(INT_MIN, "0123456789ABCDEF"); 

  //putchar('\n');
}
